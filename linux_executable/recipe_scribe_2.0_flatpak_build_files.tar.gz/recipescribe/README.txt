
This tarball is for building a flatpak of Recipe Scribe.
While the executable will work fine, it will not be extracted into a proper directory, nor include the default CONFIG file.

You'll probably prefer to download the recipe_scribe_2.0_linux_executable.tar.gz located here:
https://github.com/cerebralnomad/Recipe-Scribe/releases/download/v2.0-stable/recipe_scribe_2.0_linux_executable.tar.gz

