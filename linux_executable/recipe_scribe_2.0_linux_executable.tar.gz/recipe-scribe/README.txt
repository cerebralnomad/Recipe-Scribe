
This tarball contains the standalone executable and the program icon.
The icon is for making a program shortcut in your dock or system menu.
It is built in to the executable, so if you run the program from the CLI
with ./recipe_scribe-2.0.py the icon will be displayed in the dock.

The first time you run the program, use the config menu to set your
default save path, the root directory of your recipe folder.
FOr example: /home/USER/Documents/recipes
This is required to be set for the search feature to work.

If you are replacing a previous version of the program with this one, 
delete your existing CONFIG file and let it recreate it for you.
The new features are not included in the old CONFIG and it will fail to
run. 

A copy of a base CONFIG file for this version is included in the 
tarball. It has to be in the same directory as the executable.
If you delete it, the program will recreate it on the next launch
with the default options.

You can place this executable anywhere you want in your filesystem. 
 
