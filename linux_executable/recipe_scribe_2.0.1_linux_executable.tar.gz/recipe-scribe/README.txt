
This tarball contains the standalone executable and the program icon.
The icon is in case you want to make a custom a program shortcut in your dock or system menu.
It is built in to the executable, so if you run just by clicking on it directly, 
the icon will be used.

The first time you run the program, use the config menu to set your
default save path, the root directory of your recipe folder.
For example: /home/USER/Documents/recipes
This is required to be set for the search feature to work.

As of version 2.0.1 the old CONFIG file is no longer used.
Now a file called recipe_scribe.conf will be created in ~/.config 

If you are replacing a previous version of the program with this one, 
the old CONFIG file in the program directory will no longer be used and your
settings will revert to the defaults, so you'll need to change them to your 
preference again. 

You can place this executable anywhere you want in your filesystem. 
 
